//1. Ways to print in javascript
//console.log("Hello World");
//alert("Me");
//document.write("this is document write");

//2. Javascript console API
// console.log("Hello World", 4 + 6, Another log);
// console.warn("this is warning");
// console.error("This is an error");

// 3. Javascript variables
// What are variables? - containers to store data value

/*
multi 
line 
comments
*/

// var number1 = 34;
// var number2 = 56;
// console.log(number1 + number2);

// // 4. Data types in Javascript
// // Numbers
// var num1 = 455;
// var num2 = 56.76;

// //Strings
// var str1 = "This is a string";
// var str2 = 'This is a string';

// //Objects
// var marks = {
//     ravi: 34,
//     shubham: 78, 
//     harry: 99.977,
// }
// console.log(marks)


// do{
//     console.log(arr[j]);
//     j++
// } while(j < arr.length);
// var arr = [1,2,3,4,5,6,7];
// for(var i=0 ; i<Array.length ; i++){
//     if(i==2){
//         //break;
//         continue;
//     }
//     console.log(arr[i+1]);
// }

Let myArr = ["Fan", "Camera", 34, null, true];
// Arrays Methods
